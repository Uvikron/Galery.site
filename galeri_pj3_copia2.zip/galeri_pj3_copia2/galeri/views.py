from django.shortcuts import render, redirect
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.forms import AuthenticationForm
#from django.contrib import messages
from .forms import UserRegistrationForm

# Create your views here.

def home(request):
    return render(request,'index.html')

def logi(request):
    return render(request, "login.html")

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect(home)
            else:
                form.add_error(None, 'Invalid username or password.')
    else:
        form = AuthenticationForm()

    return render(request, 'login.html', {'form': form})

def logout(request):
    return render(request, "logout.html")

def logout_view(request):
    if request.user.is_authenticated:
        print(f"Logging out user: {request.user.username}")
        logout(request)
        print("User logged out successfully.")
    else:
        print("User is not authenticated.")
    return redirect(home)

def reset(request):
    return render(request, "pass_reset.html")

def regig_complete(request):
    return render(request, "regig_complete.html")

def register(request):
    #return render(request, "register.html")
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            new_user = form.save(commit=False)
            new_user.set_password(form.cleaned_data['password'])
            new_user.save()
            return redirect('regig_complete.html')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})