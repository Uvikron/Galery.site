from django.contrib import admin
from django.urls import path, include
from galeri import views
from .views import home, logi, reset, regig_complete, register, logout

urlpatterns = [
    path('', home),
    path('login.html', logi,),
    path('login/', views.login_view, name='login'),
    path('logout.html', logout, name='logout'),
    path('pass_reset.html', reset),
    path('regig_complete.html', regig_complete),
    path('register.html', register, name='register'),
    #path('', views.register, name='register'),
    path('logout/', views.logout_view, name='logout'),
]
