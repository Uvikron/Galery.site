# forms.py
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(widget=forms.PasswordInput, label='Confirm password')

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def clean_password2(self):
        cd = self.cleaned_data
        if cd['password'] != cd['password2']:
            raise forms.ValidationError('Passwords don\'t match.')
        return cd['password2']

class CustomAuthenticationForm(AuthenticationForm):
    remember_me = forms.BooleanField(required=False, label='Remember Me')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['remember_me'].widget.attrs.update({'class': 'form-check-input'})  # Optional: Add CSS classes

    def clean(self):
        cleaned_data = super().clean()
        remember_me = cleaned_data.get('remember_me')
        # Perform any additional validation if needed
        return cleaned_data