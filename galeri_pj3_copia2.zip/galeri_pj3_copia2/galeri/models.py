from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db import models

# Create your models here.

class MyProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    description = models.CharField(max_length=100)

@receiver(post_save, sender=User)
def my_handler(sender, **kwargs):
    if kwargs.get('created', False):
        MyProfile.objects.create(user=kwargs['instance'])

#class Itens(models.Model):        --(!!Descontinued!!)--
#    S_name = models.CharField(max_length=255, default='Unnamed site')
#    S_url = models.URLField
#    def __str__(self):
#        return self.S_name