from accounts import views
from django.urls import path
from .views import log

urlpatterns = [
    path('', log),
    path('', views.register, name='register'), 
] 